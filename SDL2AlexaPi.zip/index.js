// Raspberry Pi to Alexa
// SwitchDoc Labs 2018 www.switchdoc.com
// Version 1.0


var PubNub = require("pubnub");


var JSONMessage;   // contains the JSON message from Smart Plant Pi, stripped of pubnub history headers

var pubnub =  new PubNub({
    ssl           : true,  
    publish_key   : "pub-c-xxx",
    subscribe_key : "sub-c-xxx",
 
});
var subscribechannel = 'Pi2Alexa_Status';
var publishchannel = 'Pi2Alexa_Data';




/**
 * App ID for the skill
 */
var APP_ID = 'amzn1.ask.skill.xxxx'; //replace with "amzn1.echo-sdk-ams.app.[your-unique-value-here]";

/**
 * The AlexaSkill prototype and helper functions
 */
var AlexaSkill = require('./AlexaSkill');

/**
 * Echobot is a child of AlexaSkill.
 * To read more about inheritance in JavaScript, see the link below.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Introduction_to_Object-Oriented_JavaScript#Inheritance
 */



var SmartPlantPiControl = function () {
    

    	
    AlexaSkill.call(this, APP_ID);

};


    
// Extend AlexaSkill
SmartPlantPiControl.prototype = Object.create(AlexaSkill.prototype);
SmartPlantPiControl.prototype.constructor = SmartPlantPiControl;



SmartPlantPiControl.prototype.intentHandlers = {
	




	
    // register custom intent handlers
    
    // about intent
   about: function (intent, session, response) {
	   var gpioNum = 0;
	   var myText;
	   	console.log("in about");;
            // Parse the promise to construct the request
      myText = "This is the Raspberry Pi and Alexa skill.  Learn about the Internet of Things and Alexa.  Try L E D On, L E D off, On, Off, about, timestamp and status.   You can find more at www.switchdoc.com";
	  response.tell(myText);
	  return;

    },
    
 
    // timestamp intent
         timestamp: function (intent, session, response) {

var first = pubnub.history({
    channel: subscribechannel,
    reverse: false, // Setting to true will traverse the time line in reverse starting with the oldest message first.
    count: 1, // how many items to fetch


}).then((response) => { 
 
    console.log("response=",JSON.stringify(response));
    var obj = JSON.parse(JSON.stringify(response));
    
    var msgs = obj.messages;
    var msg = msgs[0];
    var parsedJSON = JSON.parse(JSON.stringify(msg.entry));
    JSONMessage = parsedJSON;

    
	return;

    
}).catch((error) => { 
    console.log(error) ;
    console.log("in error");
});

  return Promise.all([first])
        .then(function (responses) {
            var myText;
            var myTime;
            myTime = JSONMessage.TimeStamp;
            myTime = myTime.replace(" ", "  at Time:  ");
 
                 myText = "";
                 
                 myText = "  I last heard from The Raspberry Pi on Date: "+myTime+ ".  Time is From the Raspberry Pi";
	             response.tell(myText);


            return ;
        });

    },
    
 
    // status intent
    status: function (intent, session, response) {
		   


var first = pubnub.history({
    channel: subscribechannel,
    reverse: false, // Setting to true will traverse the time line in reverse starting with the oldest message first.
    count: 1, // how many items to fetch

}).then((response) => { 
    var obj = JSON.parse(JSON.stringify(response));

    var msgs = obj.messages;
    var msg = msgs[0];
    var parsedJSON = JSON.parse(JSON.stringify(msg.entry));
    JSONMessage = parsedJSON;

	return;
 
}).catch((error) => { 
    console.log(error) 
});

  return Promise.all([first])
        .then(function (responses) {
            var myText;
            myText = "";
            
            
          
            myText = "Raspberry Pi Status. ";

            myText = myText +  " L E D is  "+ JSONMessage.Pi2Alexa_LEDState+ "."; 
            myText = myText +  " Pi2Alexa Version:  "+ JSONMessage.Pi2Alexa_Version+ "."; 
         var myTime;
            myTime = JSONMessage.TimeStamp;
            myTime = myTime.replace(" ", "  at Time:  ");
 
                
                 
                 myText = myText + "  I last heard from The Raspberry Pi on Date: "+myTime+ ".  Time is From the Raspberry Pi";


	        response.tell(myText);


            return ;
        });


    },
    
    
 // LEDON intent
 LEDON: function (intent, session, response) {
		   
  	   var message = {
          "LED"   : "On"
	        };
	        
	var   myText;        
    pubnub.publish(
    {
        message: message,
        channel: publishchannel,
        sendByPost: false, // true to send via post
        storeInHistory: false, //override default storage options
     
    }, 
    function (status, statusresponse) {
        if (status.error) {
           var   myText;
             myText = "request failed.";
              response.tell(myText);

            console.log(status)
        } else {
            console.log("message Published w/ timetoken", response.timetoken);
            
             myText = "L E D turned on.";
             response.tell(myText);
        }
    }
);
 

    },
    
 // LEDOFF intent
 LEDOFF: function (intent, session, response) {
		   
  	   var message = {
          "LED"   : "Off"
	        };
	        
	var   myText;        
    pubnub.publish(
    {
        message: message,
        channel: publishchannel,
        sendByPost: false, // true to send via post
        storeInHistory: false, //override default storage options
     
    }, 
    function (status, statusresponse) {
        if (status.error) {
           var   myText;
             myText = "request failed.";
              response.tell(myText);

            console.log(status)
        } else {
            console.log("message Published w/ timetoken", response.timetoken);
            
             myText = "L E D turned off.";
             response.tell(myText);
        }
    }
);
 
    },
    default: function (intent, session, response) {
        response.ask("Try again");
    },
    
};


// Create the handler that responds to the Alexa Request.
exports.handler = function (event, context) {
	
 
    

    // Create an instance of the Echobot skill.
    var smartplantpicontrol = new SmartPlantPiControl();

    smartplantpicontrol.execute(event, context);
   
   
    

};




